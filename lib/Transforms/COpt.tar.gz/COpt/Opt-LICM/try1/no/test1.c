int main(void)
{
	int x = 5;
	int r = 10;
	int y = 0;
	for (int i = 0; i < 42*x; i++) 
	{
		y = 5;
		x = 6;
		r += y;
	}
	return 0;
};
