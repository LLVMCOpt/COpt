void foo(int a, int b)
{
	int c = a+b;
	int d = 0;
	if (c>0)
		d = 1;
	d = a+b;
}
