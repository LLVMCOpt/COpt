int foo(int a, int b)
{
	int c;
	if (a>b)
	{
		c = a+b;
		int d = c+b;	
	}
	else
	{
		c = a+b;
	}
	c = a+b;
	return 0;
}
