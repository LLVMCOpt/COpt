int foo(int a, int b, int c)
{

	int d;
	switch(c)
	{
		case 1: d = a+b;
				break;
		case 2: d = a+b;
				break;
		case 3: d = a+b;
				break;
		case 4: d = a+b;
				break;
		case 5: d = a+b;
				break;
		default: d = a+b;
	}
	
	d=a+b;
	
	return d;
}
