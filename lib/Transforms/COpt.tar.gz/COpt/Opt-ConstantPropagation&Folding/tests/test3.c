void foo(int a, int b)
{
	a = 15;
	b = 20;
	int c = a*b;
	int d = a+b;
	a*=10;
	b = a+b;
}
