int foo()
{
	int a=1, b=2;
	return a+b;
}
