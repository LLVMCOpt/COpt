int foo(int a, int b)
{
	if (b > 20)
		a = 10;
	else
		a = 10;
	return a*4;
}
