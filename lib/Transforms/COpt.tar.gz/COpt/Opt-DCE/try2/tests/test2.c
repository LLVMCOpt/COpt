void foo()
{
	int a=10, b;
	if (a==10)
		a = 2;
	else
		b = 3;
}
