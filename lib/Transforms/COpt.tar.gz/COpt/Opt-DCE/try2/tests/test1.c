void foo(int a, int b)
{
	int x, y, z, q;
	y = a + b;
	q = a*b;
	y+=5;
	x = y*y;
	z = x;
	b = z+2;
}
