int foo(int e, int f, int g)
{
	int a, b, c, d;
	a = 1; b = 2; c = 1; d = 2;
	if (e>10)
	{
		f = a+b;
		g = c+d;
	}
	return g;
}
