int calc_sum(int a, int b)
{
	return a + b;
}
int main()
{
	int a=5, b=10, sum;
	sum = calc_sum(a,b);
	return 0;
}
