make -f makefileCompile arg="$1"
