int foo(int a, int b, int c, int d)
{
	int e, f, g, h;
	e = b+c;
	f = a-d;
	g = b+c;
	h = a-d;
	return h;
}
