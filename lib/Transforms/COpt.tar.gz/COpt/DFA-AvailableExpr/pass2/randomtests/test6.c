int foo(int a, int b)
{
	int c;
	c = 3+1;
	if (a>b)
		c = 3+1;
	c = 3+1;
	return 0;
}
