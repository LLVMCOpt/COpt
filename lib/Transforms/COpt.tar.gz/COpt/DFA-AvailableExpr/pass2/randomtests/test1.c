int foo(int a, int b)
{
	int c;
	c = a+b;
	if (a>b)
		c = a+b;
	c = a+b;
	return 0;
}
