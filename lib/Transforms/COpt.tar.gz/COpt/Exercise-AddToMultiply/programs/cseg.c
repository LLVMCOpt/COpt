#include <stdio.h>
int main(int argc, const char** argv) 
{
    int num;
    int b;
    b = 1;
    num = 4*3/b;
    b = 4*3/b;
    return 5;
}
