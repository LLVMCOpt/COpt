#include <stdio.h>
int main(int argc, const char** argv) 
{
    int num;
    scanf("%i", &num);
    printf("%i\n", num + 2);
    return 0;
}
