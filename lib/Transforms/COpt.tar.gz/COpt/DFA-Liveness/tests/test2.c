int foo(int y)
{
	int x;
	x = 5;
	y = y+9;
	return y;
}
